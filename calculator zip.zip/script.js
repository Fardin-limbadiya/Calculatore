document.addEventListener('DOMContentLoaded', () => {
      const resultInput = document.getElementById('result');
      let currentInput = '';
      let previousInput = '';
      let operator = '';
      let isCalculated = false;
      
  
      const clearInput = () => {
          currentInput = '';
          previousInput = '';
          operator = '';
          resultInput.value = '';
          isCalculated = false;
          console.log('Cleared Input');
      };
  
      const updateDisplay = () => {
          resultInput.value = currentInput;
         
      };
  
      const appendNumber = (number) => {
          if (isCalculated) {
              currentInput = '';
              isCalculated = false;
          }
          currentInput += number;
          updateDisplay();
          console.log(`Appended Number: ${number}, Current Input: ${currentInput}`);
      };
  
      const chooseOperator = (op) => {
          if (currentInput === '') return;
          if (previousInput !== '') {
              calculate();
          }
          operator = op;
          previousInput = currentInput;
          currentInput = '';
          console.log(`Chosen Operator: ${operator}, Previous Input: ${previousInput}, Current Input reset`);
      };
  
      const calculate = () => {
          let computation;
          const prev = parseFloat(previousInput);
          const curr = parseFloat(currentInput);
          if (isNaN(prev) || isNaN(curr)) return;
          switch (operator) {
              case '+':
                  computation = prev + curr;
                  break;
              case '-':
                  computation = prev - curr;
                  break;
              case '*':
                  computation = prev * curr;
                  break;
              case '/':
                  computation = prev / curr;
                  break;
              default:
                  return;
          }
          console.log(`Calculating: ${prev} ${operator} ${curr} = ${computation}`);
          currentInput = computation;
          operator = '';
          previousInput = '';
          isCalculated = true;
          updateDisplay();
      };
  
      document.querySelectorAll('button').forEach(button => {
          button.addEventListener('click', () => {
              if (button.innerText >= '0' && button.innerText <= '9') {
                  appendNumber(button.innerText);
              } else if (button.innerText === 'C') {
                  clearInput();
              } else if (button.innerText === '=') {
                  calculate();
              } else {
                  chooseOperator(button.innerText);
              }
          });
      });
  });
  